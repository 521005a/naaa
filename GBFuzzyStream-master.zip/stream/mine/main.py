import csv
import sys
import time
import pandas as pd
sys.path.append(r"D:/xueshu/liushi/GBFuzzyStream-master/GBFuzzyStream-master")
from stream.mine.MBStream import start

# from stream.mine.MBStream import start

if __name__ == '__main__':
    # dataset = "RBF3_40000(1000).csv"
    dataset = "RBF3_40000(1000)"

    dataset_path = "withLabel"
    s = time.time()
    csv1 = pd.read_csv("../data/"+dataset_path+"/" + dataset+'.csv', header=None)
    plot_evaluate_flag = False  # Whether to enable drawing function
    # 遍历参数网格
    # 定义参数网格
    lams = [0.2, 0.6, 1.0, 1.4, 1.6, 2.0]
    thresholds = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
    # lams = [ 1.0,1.2]
    # thresholds = [0.3, 0.8]
    max_result = []
    best_score = 0
    max_score=0
    for lam in lams:
        for threshold in thresholds:
           score,result=start(csv1, dataset, plot_evaluate_flag,lam,threshold)
           if score>max_score:
               max_result=result
    with open('../notebooks/experiments/'+dataset+'.csv', newline='',
              mode='a+') as f:
        # create the csv writer
        writer = csv.writer(f)
        # acc nmi ari mean_purity
        row = [max_result[0], max_result[1], max_result[2], max_result[3]]
        writer.writerow(row)


