# -*- coding: utf-8 -*-
"""
@Time ： 2023/5/30 20:52
@Auth ： daiminggao
@File ：DPC.py
@IDE ：PyCharm
@Motto:咕咕咕
"""
import numpy as np


def get_cluster_num(datas):
    dists = getDistanceMatrix(datas)
    dc = select_dc(dists)
    rho = get_density(dists, dc)
    deltas, nearest_neiber = get_deltas(dists, rho)
    centers = find_centers_auto(rho, deltas)
    return len(centers)


def get_cluster_DPC(datas):
    dists = getDistanceMatrix(datas)
    percent = 2
    while True:
        dc = select_dc(dists, percent)
        rho = get_density(dists, dc)
        deltas, nearest_neiber = get_deltas(dists, rho)
        centers = find_centers_auto(rho, deltas)
        if len(centers) >= 2:
            labs = cluster_PD(rho, centers, nearest_neiber)
            return labs, len(centers)
        else:
            if percent <= 80:
                percent = percent + 1
            else:
                labs = cluster_PD(rho, centers, nearest_neiber)
                return labs, len(centers)


def getDistanceMatrix(datas):
    N, D = np.shape(datas)
    dists = np.zeros([N, N])
    for i in range(N):
        for j in range(N):
            vi = datas[i, :]
            vj = datas[j, :]
            dists[i, j] = np.sqrt(np.dot((vi - vj), (vi - vj)))
    return dists


# 找到密度计算的阈值dc
# 要求平均每个点周围距离小于dc的点的数目占总点数的1%-2%
def select_dc(dists, percent=2):
    '''算法1'''
    N = np.shape(dists)[0]
    tt = np.reshape(dists, N * N)
    position = int(N * (N - 1) * percent / 100)
    dc = np.sort(tt)[position + N]
    return dc


# 计算每个点的局部密度
def get_density(dists, dc, method=None):
    '''
        方法一：截断核
        方法二：高斯核
    '''
    N = np.shape(dists)[0]
    rho = np.zeros(N)
    for i in range(N):
        if method == None:
            rho[i] = np.where(dists[i, :] < dc)[0].shape[0] - 1
        else:
            rho[i] = np.sum(np.exp(-(dists[i, :] / dc) ** 2)) - 1
    return rho


# 计算每个数据点的密度距离
# 即对每个点，找到密度比它大的所有点
# 再在这些点中找到距离其最近的点的距离
def get_deltas(dists, rho):
    N = np.shape(dists)[0]
    deltas = np.zeros(N)
    nearest_neiber = np.zeros(N)
    # 将密度从大到小排序
    index_rho = np.argsort(-rho)
    for i, index in enumerate(index_rho):
        # 对于密度最大的点
        if i == 0:
            continue
        # 对于其他的点
        # 找到密度比其大的点的序号
        index_higher_rho = index_rho[:i]
        # 获取这些点距离当前点的距离,并找最小值
        deltas[index] = np.min(dists[index, index_higher_rho])
        # 保存最近邻点的编号
        index_nn = np.argmin(dists[index, index_higher_rho])
        nearest_neiber[index] = index_higher_rho[index_nn].astype(int)
    deltas[index_rho[0]] = np.max(deltas)
    return deltas, nearest_neiber


# 通过阈值选取 rho与delta都大的点
# 作为聚类中心
def find_centers_auto(rho, deltas):
    rho_threshold = (np.min(rho) + np.max(rho)) * 0.12
    delta_threshold = (np.min(deltas) + np.max(deltas)) * 0.12
    N = np.shape(rho)[0]
    centers = []
    for i in range(N):
        if rho[i] >= rho_threshold and deltas[i] > delta_threshold:
            centers.append(i)
    return centers


# 选取 rho与delta乘积较大的点作为
# 聚类中心
def find_centers_K(rho, deltas, K):
    rho_delta = rho * deltas
    centers = np.argsort(-rho_delta)
    return centers[:K]


def cluster_PD(rho, centers, nearest_neiber):
    K = np.shape(centers)[0]
    if K == 0:
        print("can not find centers")
        return
    N = np.shape(rho)[0]
    labs = -1 * np.ones(N).astype(int)
    # 首先对几个聚类中进行标号
    for i, center in enumerate(centers):
        labs[center] = i
    # 将密度从大到小排序
    index_rho = np.argsort(-rho)
    for i, index in enumerate(index_rho):
        # 从密度大的点进行标号
        if labs[index] == -1:
            # 如果没有被标记过
            # 那么聚类标号与距离其最近且密度比其大
            # 的点的标号相同
            labs[index] = labs[int(nearest_neiber[index])]
    return labs
